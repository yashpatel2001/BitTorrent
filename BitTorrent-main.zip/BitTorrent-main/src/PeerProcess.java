import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PeerProcess {
    public static void peerProcess(int peerId) {

        // Function that starts peer process

    }

    // variables for storing information from PeerInfo.cfg
    public static ArrayList<Integer> peerIDs = new ArrayList<Integer>();
    public static ArrayList<String> hostNames = new ArrayList<String>();
    public static ArrayList<Integer> ports = new ArrayList<Integer>();
    public static ArrayList<Boolean> hasFile = new ArrayList<Boolean>();

    public static void ReadPeer() {
        // Reads PeerInfo.cfg
        // Create an array list of all the read lines
        // Start in read Peers based on previous reading and call peerProcess

        try {
            input = new FileReader("src/PeerInfo.cfg");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        // ArrayList<String> list_lines = new ArrayList<String>();
        try (BufferedReader br = new BufferedReader(input)) {
            // read PeerInfo.cfg
            String line;
            while ((line = br.readLine()) != null) {
                // get peerID
                // YASH PLEASE CHECK THIS I DON'T KNOW REGEX THANKS
                Pattern to_match = Pattern.compile("[0-9+]{1,}");
                Matcher id = to_match.matcher(line);
                int temp = Integer.valueOf(id.group(1));
                peerIDs.add(temp);
                // get hostName
                to_match = Pattern.compile("");
                // YASH PLEASE DO THIS I DON'T KNOW REGEX PLS

                // get port
                // YASH YASH YASH YASH YASH YASH YASH YASH YASH YASH YASH YASH YASH YASH YASH
                // YASH YASH YASH YASH YASH YASH YASH YASH YASH
                to_match = Pattern.compile("[0-9]{1,}");
                id = to_match.matcher(line);
                temp = Integer.valueOf(id.group(1));
                ports.add(temp);

                // get hasFile
                to_match = Pattern.compile("[0-1]{1}");
                id = to_match.matcher(line);
                boolean tempbool = Boolean.parseBoolean(id.group(1));
                hasFile.add(tempbool);

            }
            // store lines as appropriate
            /*
             * Pattern to_match = Pattern.compile("([0-9]+){1,}");
             * String numberofPreffered = list_lines.get(0);
             * String unchokingInter = list_lines.get(1);
             * String optunchokingInter = list_lines.get(2);
             * String fileName = list_lines.get(3);
             * String fileSize = list_lines.get(4);
             * String piecesize = list_lines.get(5);
             * Matcher numPref = to_match.matcher(numberofPreffered);
             * Matcher unchokInt = to_match.matcher(unchokingInter);
             * Matcher optunInt = to_match.matcher(optunchokingInter);
             * Matcher filename = to_match.matcher(fileName);
             * Matcher filesize = to_match.matcher(fileSize);
             * Matcher pieceSize = to_match.matcher(piecesize);
             */

            // get and store values from respective lines
            /*
             * NumberOfPreferredNeighbors = numPref.find() ?
             * Integer.valueOf(numPref.group(1)) : 0;
             * UnchokingInterval = unchokInt.find() ? Integer.valueOf(unchokInt.group(1)) :
             * 0;
             * OptimisticUnchokingInterval = optunInt.find() ?
             * Integer.valueOf(optunInt.group(1)) : 0;
             * FileName = filename.find() ? filename.group(1) : "No file name";
             * FileSize = filesize.find() ? Integer.valueOf(filesize.group(1)) : 0;
             * PieceSize = pieceSize.find() ? Integer.valueOf(pieceSize.group(1)) : 0;
             */

            // Notes: Need to implement with regex. Use

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // variables for storing information obtained by Common.cfg
    public static int NumberOfPreferredNeighbors = 0;
    public static int UnchokingInterval = 0;
    public static int OptimisticUnchokingInterval = 0;
    public static String FileName = "default_file.dat";
    public static int FileSize = 0;
    public static int PieceSize = 0;
    public static FileReader input = null;

    // reads Common.cfg and stores values in respective variables
    public static void ReadCommon() {

        try {
            input = new FileReader("src/Common.cfg");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        ArrayList<String> list_lines = new ArrayList<String>();
        try (BufferedReader br = new BufferedReader(input)) {
            // read Common.cfg
            String line;
            while ((line = br.readLine()) != null) {
                list_lines.add(line);
            }
            // store lines as appropriate
            Pattern to_match = Pattern.compile("([0-9]+){1,}");
            String numberofPreffered = list_lines.get(0);
            String unchokingInter = list_lines.get(1);
            String optunchokingInter = list_lines.get(2);
            String fileName = list_lines.get(3);
            String fileSize = list_lines.get(4);
            String piecesize = list_lines.get(5);
            Matcher numPref = to_match.matcher(numberofPreffered);
            Matcher unchokInt = to_match.matcher(unchokingInter);
            Matcher optunInt = to_match.matcher(optunchokingInter);
            Matcher filename = to_match.matcher(fileName);
            Matcher filesize = to_match.matcher(fileSize);
            Matcher pieceSize = to_match.matcher(piecesize);

            // get and store values from respective lines
            NumberOfPreferredNeighbors = numPref.find() ? Integer.valueOf(numPref.group(1)) : 0;
            UnchokingInterval = unchokInt.find() ? Integer.valueOf(unchokInt.group(1)) : 0;
            OptimisticUnchokingInterval = optunInt.find() ? Integer.valueOf(optunInt.group(1)) : 0;
            FileName = filename.find() ? filename.group(1) : "No file name";
            FileSize = filesize.find() ? Integer.valueOf(filesize.group(1)) : 0;
            PieceSize = pieceSize.find() ? Integer.valueOf(pieceSize.group(1)) : 0;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public static void main(String[] args) {
        PeerProcess p = new PeerProcess();
        // Making a instance of the peer process so that we see multiple instances
        p.ReadCommon();
        p.ReadPeer();

    }
}
